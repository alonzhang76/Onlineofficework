/**
 * 普利美工作 —— 企业应用门户小程序
 *
 * 首页为「普利美工作」工作台，点击图标进入各子应用：
 *   1. 计件工资管理（wage）──── utils/wage-db.js
 *   2. 外贸出口管理系统（trade）── utils/trade-db.js（密码保护）
 *   3. 订单排程（schedule）──── utils/schedule-db.js
 *   4. 采购管理（purchase）──── utils/purchase-db.js
 *
 * 各子应用数据独立存储，并各自与 Supabase 云端同步
 * （命名空间 wage / trade / schedule / purchase，与网页版共用同一后端）。
 */
const wageDb = require('./utils/wage-db');
const tradeDb = require('./utils/trade-db');
const scheduleDb = require('./utils/schedule-db');
const purchaseDb = require('./utils/purchase-db');
const incomeDb = require('./utils/income-db');

App({
  onLaunch() {
    // 每次冷启动重置外贸模块的解锁状态
    this.globalData.tradeUnlocked = false;
    this.globalData.scheduleUnlocked = false;
    this.globalData.incomeExpenseUnlocked = false;
    // 本地加载
    wageDb.loadAll();
    tradeDb.loadAll();
    scheduleDb.loadAll();
    purchaseDb.loadAll();
    incomeDb.loadAll();
    // 云端拉取覆盖（未配置 Supabase 时静默跳过）
    wageDb.syncFromCloud();
    tradeDb.syncFromCloud();
    scheduleDb.syncFromCloud();
    purchaseDb.syncFromCloud();
    incomeDb.syncFromCloud();
  },

  globalData: {
    // 公司名称（各页面页首统一展示）
    companyName: '普利美（常州）环境工程科技有限公司',
    companyNameEn: 'PULIMEI (CHANGZHOU) ENVIRONMENTAL ENGINEERING TECHNOLOGY CO., LTD.',
    // 外贸出口模块访问密码（点击门户「外贸出口」需验证）
    tradePassword: 'alon2601',
    // 订单排程模块访问密码
    schedulePassword: 'anny2601',
    // 收支模块访问密码
    incomeExpensePassword: 'anny2601',
    // 本次启动内是否已通过验证（冷启动重置为 false）
    tradeUnlocked: false,
    // 订单排程模块解锁状态（冷启动重置）
    scheduleUnlocked: false,
    // 收支模块解锁状态（冷启动重置）
    incomeExpenseUnlocked: false,
    // 门户应用清单
    apps: [
      {
        key: 'wage',
        name: '计件工资',
        nameEn: 'Piece-rate Wage',
        desc: '登记 · 汇总 · 统计',
        icon: '💰',
        color: '#007AFF',
        url: '/pages/wage/entry/entry'
      },
      {
        key: 'trade',
        name: '外贸出口',
        nameEn: 'Export Trade',
        desc: '订单 · 收汇 · 报表',
        icon: '🚢',
        color: '#34C759',
        url: '/pages/trade/hub/hub'
      },
      {
        key: 'schedule',
        name: '订单排程',
        nameEn: 'Order Schedule',
        desc: '排程 · 生产 · 收款',
        icon: '📅',
        color: '#FF9500',
        url: '/pages/schedule/hub/hub'
      },
      {
        key: 'income',
        name: '收支管理',
        nameEn: 'Income & Expense',
        desc: '流水 · 待办 · 统计',
        icon: '💹',
        color: '#00C7BE',
        url: '/pages/income/hub/hub'
      },
      {
        key: 'purchase',
        name: '采购管理',
        nameEn: 'Purchase',
        desc: '订单 · 发票 · 付款',
        icon: '🛒',
        color: '#5856D6',
        url: '/pages/purchase/hub/hub'
      }
    ]
  }
});

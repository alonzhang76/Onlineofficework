/* ===== 发票与付款系统 - CloudBase 数据访问层 =====
 * 底层使用 app_data_store 表（id=store_key, data=JSON payload）
 * 集合：reim_invoices / reim_users / reim_companies / reim_review_log
 */
window.REIM_STORE_LOADED = true;

const STORE_KEYS = {
  invoices: 'reim_invoices',
  users: 'reim_users',
  companies: 'reim_companies',
  reviewLog: 'reim_review_log',
  payments: 'reim_payments',
};

/* 无票付款阶段：预付款 / 进度款 / 尾款 / 其他 */
var PAYMENT_STAGES = ['预付款', '进度款', '尾款', '其他'];

function waitForSupabase(timeout) {
  timeout = timeout || 20000;
  var start = Date.now();
  return new Promise(function (resolve, reject) {
    function check() {
      if (window.supabase && window.supabase.auth && window.supabase.from) {
        resolve(window.supabase); return;
      }
      if (Date.now() - start > timeout) { reject(new Error('CloudBase 初始化超时')); return; }
      setTimeout(check, 100);
    }
    check();
  });
}

/* ---------- 通用集合读写 ----------
 * 标准行形态（与 apps/cloudbase-sync.js、wage、小程序端 utils/cloudbase.js 一致）：
 *   物理行 { id: store_key, data: { store_key, payload, updated_at } }
 * 兼容层 _expand 会把 data 内字段展平到行上 → 读取时取 row.payload。
 * 历史形态（旧版 store.js upsert {id, data:数组}）展平后是 row.data，做兜底兼容。 */
async function storeGet(key) {
  var sb = await waitForSupabase();
  var r = await sb.from('app_data_store').select('*').eq('id', key);
  if (r.error) throw r.error;
  var row = (r.data && r.data[0]) || null;
  if (!row) return null;
  if (row.payload !== undefined && row.payload !== null) return row.payload;
  return (row.data !== undefined && row.data !== null) ? row.data : null;
}

async function storeSet(key, payload) {
  var sb = await waitForSupabase();
  var r = await sb.from('app_data_store').upsert(
    { store_key: key, payload: payload, updated_at: new Date().toISOString() },
    { onConflict: 'store_key' }
  );
  if (r.error) throw r.error;
  return true;
}

/* ---------- 发票集合 ---------- */
// 数值字段强制转 Number：历史导入/恢复的 JSON 可能携带字符串金额，
// 会导致页面 reduce 拼接后调 toFixed 崩溃（台账/统计全挂）
var INVOICE_NUM_FIELDS = ['amount', 'tax_amount', 'total_amount', 'paid_amount'];

async function getInvoices() {
  var data = await storeGet(STORE_KEYS.invoices);
  var list = Array.isArray(data) ? data : [];
  await repairMissingDirections(list);
  list.forEach(function (r) {
    INVOICE_NUM_FIELDS.forEach(function (f) {
      var n = parseFloat(r[f]);
      r[f] = isFinite(n) ? n : 0;
    });
    var pi = paymentInfo(r.total_amount, r.paid_amount);
    r.payment_status = pi.status;
    r.balance = pi.balance;
  });
  return list;
}

async function saveInvoices(list) {
  return storeSet(STORE_KEYS.invoices, list);
}

/* ---------- 用户集合 ---------- */
async function getUsers() {
  var data = await storeGet(STORE_KEYS.users);
  return Array.isArray(data) ? data : [];
}

async function saveUsers(list) {
  return storeSet(STORE_KEYS.users, list);
}

async function findUserByEmail(email) {
  var users = await getUsers();
  return users.find(function (u) { return (u.email || u.username) === email; }) || null;
}

async function findUserByUsername(username) {
  var users = await getUsers();
  return users.find(function (u) { return (u.username || u.email) === username; }) || null;
}

/* ---------- 密码哈希（兼容 werkzeug pbkdf2:sha256 格式） ---------- */
var PBKDF2_ITERATIONS = 260000;
var SALT_CHARS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

function randomSalt(len) {
  var s = '';
  var arr = new Uint8Array(len);
  crypto.getRandomValues(arr);
  for (var i = 0; i < len; i++) s += SALT_CHARS[arr[i] % SALT_CHARS.length];
  return s;
}

async function generatePasswordHash(password) {
  var salt = randomSalt(16);
  var enc = new TextEncoder();
  var keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  var bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: enc.encode(salt), iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    keyMaterial, 256
  );
  var hash = Array.from(new Uint8Array(bits)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  return 'pbkdf2:sha256:' + PBKDF2_ITERATIONS + '$' + salt + '$' + hash;
}

async function checkPasswordHash(password, hash) {
  if (!hash) return false;
  var parts = hash.split('$');
  if (parts.length !== 3) return false;
  var methodParts = parts[0].split(':');
  var salt = parts[1];
  var expected = parts[2];
  var enc = new TextEncoder();
  var actual;
  if (methodParts[0] === 'pbkdf2' && methodParts[1] === 'sha256') {
    var iterations = parseInt(methodParts[2], 10);
    var keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
    var bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt: enc.encode(salt), iterations: iterations, hash: 'SHA-256' },
      keyMaterial, 256
    );
    actual = Array.from(new Uint8Array(bits)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  } else if (methodParts[0] === 'scrypt') {
    // scrypt:N:r:p
    var N = parseInt(methodParts[1], 10);
    var r = parseInt(methodParts[2], 10);
    var p = parseInt(methodParts[3], 10);
    var pwBytes = Array.from(enc.encode(password));
    var saltBytes = Array.from(enc.encode(salt));
    actual = await new Promise(function (resolve, reject) {
      var scryptFn = (typeof scrypt === 'function') ? scrypt : (scrypt && scrypt.scrypt);
      if (typeof scryptFn !== 'function') { reject(new Error('scrypt-js not loaded')); return; }
      scryptFn(pwBytes, saltBytes, N, r, p, 32, function (err, result) {
        if (err) { reject(err); return; }
        var h = '';
        for (var i = 0; i < result.length; i++) h += result[i].toString(16).padStart(2, '0');
        resolve(h);
      });
    });
  } else {
    return false;
  }
  if (actual.length !== expected.length) return false;
  var diff = 0;
  for (var i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

/* ---------- 公司集合 ---------- */
async function getCompanies() {
  var data = await storeGet(STORE_KEYS.companies);
  return Array.isArray(data) ? data : [];
}

async function saveCompanies(list) {
  return storeSet(STORE_KEYS.companies, list);
}

/* ---------- 审核日志 ---------- */
async function getReviewLogs() {
  var data = await storeGet(STORE_KEYS.reviewLog);
  return Array.isArray(data) ? data : [];
}

async function saveReviewLogs(list) {
  return storeSet(STORE_KEYS.reviewLog, list);
}

/* ---------- 无票付款记录（预付款 / 进度款 / 尾款 / 其他） ----------
 * 与发票付款的区别：不绑定 invoice_no（可选），以「合同号(project)」为锚点，
 * 支持「先付款后开票」场景。purchase-integrated 会读取 reim_payments 并按
 * project（合同号）汇总到合同已付金额。
 * 字段说明：
 *   stage         付款阶段（预付款/进度款/尾款/其他）
 *   amount        本次付款金额
 *   payment_date  付款日期
 *   payment_method 付款方式（电汇/承兑/现金）
 *   seller_name   收款方（供应商）
 *   project       所属合同号（用于采购侧关联）
 *   invoice_no    关联发票号（可选，空=无票付款）
 *   payee         收款对象（销售方/报销人），默认销售方
 *   settle        结算方式（正常付款/仅做账），默认正常付款
 *   company_id / company_short  我方公司抬头
 *   direction     进项/销项，默认进项
 *   remark        备注
 */
var PAYMENT_NUM_FIELDS = ['amount'];

async function getPayments() {
  var data = await storeGet(STORE_KEYS.payments);
  var list = Array.isArray(data) ? data : [];
  list.forEach(function (r) {
    PAYMENT_NUM_FIELDS.forEach(function (f) {
      var n = parseFloat(r[f]);
      r[f] = isFinite(n) ? n : 0;
    });
  });
  return list;
}

async function savePayments(list) {
  return storeSet(STORE_KEYS.payments, list);
}

/* ---------- 供应商名称（跨应用读取采购系统 pis_suppliers 主数据） ----------
 * 用于「无票付款登记」收款方关键字筛选；读取失败/无数据时返回空数组，
 * 调用方回退到发票 seller_name。 */
async function getSupplierNames() {
  try {
    // 采购一体化（purchase-integrated）云端供应商主数据：
    // 物理行 id / data.store_key 均为带应用前缀的 purchase-integrated__pis_suppliers，
    // 名称字段 supplierName（早期数据可能为 name，做兜底）
    var data = await storeGet('purchase-integrated__pis_suppliers');
    var list = Array.isArray(data) ? data : [];
    var names = [];
    list.forEach(function (s) {
      var n = String((s && (s.supplierName || s.name)) || '').trim();
      if (n && names.indexOf(n) < 0) names.push(n);
    });
    names.sort(function (a, b) { return a.localeCompare(b, 'zh-Hans-CN'); });
    return names;
  } catch (e) {
    return [];
  }
}

/* ---------- 采购合同列表（跨应用读取采购系统 pis_orders 主数据） ----------
 * 付款登记「关联合同」下拉的数据源：以前只读本机 localStorage.pis_orders，
 * 换浏览器 / 换设备时为空，导致发票 project 存空、采购侧对账归集不到合同。
 * 这里与 supplier 主数据一样直连云端行，读不到时由调用方回退 localStorage。 */
async function getContractList() {
  var data = await storeGet('purchase-integrated__pis_orders');
  var list = Array.isArray(data) ? data : [];
  return list
    .filter(function (o) { return o && o.contractNumber; })
    .map(function (o) {
      return {
        contractNumber: String(o.contractNumber),
        supplier: o.supplier || '',
        totalAmount: parseFloat(o.totalAmount) || 0,
        orderDate: o.orderDate || ''
      };
    });
}

/* ---------- 公司抬头匹配（进项/销项方向） ---------- */
function _normName(s) {
  // NFKC 归一：全角括号（）→半角()、全角英数→半角，再去空白
  // （发票 OCR/数电票常把购买方括号解析成半角，公司抬头是全角，不统一会匹配失败 → direction=null）
  return String(s || '').normalize('NFKC').replace(/\s+/g, '');
}

function matchCompany(companies, buyer, seller) {
  var b = _normName(buyer), s = _normName(seller);
  if (!b && !s) return { company_id: null, direction: null, company_short: null };
  for (var i = 0; i < companies.length; i++) {
    var c = companies[i];
    if (!c.active) continue;
    var n = _normName(c.name);
    if (n && b && (n.indexOf(b) >= 0 || b.indexOf(n) >= 0)) {
      return { company_id: c.id, direction: '进项', company_short: c.short_name || c.name };
    }
  }
  for (var j = 0; j < companies.length; j++) {
    var c2 = companies[j];
    if (!c2.active) continue;
    var n2 = _normName(c2.name);
    if (n2 && s && (n2.indexOf(s) >= 0 || s.indexOf(n2) >= 0)) {
      return { company_id: c2.id, direction: '销项', company_short: c2.short_name || c2.name };
    }
  }
  return { company_id: null, direction: null, company_short: null };
}

/* 重算全部发票的方向（公司抬头变更后调用） */
async function recomputeAllDirections() {
  var companies = await getCompanies();
  var invoices = await getInvoices();
  for (var i = 0; i < invoices.length; i++) {
    var inv = invoices[i];
    var m = matchCompany(companies, inv.buyer_name, inv.seller_name);
    inv.company_id = m.company_id;
    inv.direction = m.direction;
    inv.company_short = m.company_short;
  }
  await saveInvoices(invoices);
  return invoices;
}

/* 自愈：历史发票 direction 为空的（录入时抬头未命中，如全/半角括号差异），
 * 读取时按当前公司抬头重算一次并回写，保证台账/进销项/付款统计口径一致。
 * 只补空值，不覆盖已有 direction，无缺失时零写开销。 */
async function repairMissingDirections(list) {
  var need = list.filter(function (r) { return !r.direction; });
  if (!need.length) return;
  var companies = await getCompanies();
  var changed = false;
  need.forEach(function (r) {
    var m = matchCompany(companies, r.buyer_name, r.seller_name);
    if (m.direction) {
      r.direction = m.direction;
      r.company_id = m.company_id;
      r.company_short = m.company_short;
      changed = true;
    }
  });
  if (changed) await saveInvoices(list);
}

/* ---------- 付款状态计算 ---------- */
function paymentInfo(total, paid) {
  if (total == null) return { status: '-', balance: null };
  paid = paid || 0;
  var bal = Math.round((total - paid) * 100) / 100;
  if (paid <= 0.005) return { status: '未付款', balance: bal };
  if (bal > 0.005) return { status: '部分付款', balance: bal };
  return { status: '已付清', balance: 0 };
}

/* ---------- ID 生成 ---------- */
function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/* ---------- 导出到全局 ---------- */
window.ReimStore = {
  STORE_KEYS: STORE_KEYS,
  waitForSupabase: waitForSupabase,
  storeGet: storeGet,
  storeSet: storeSet,
  getInvoices: getInvoices,
  saveInvoices: saveInvoices,
  getUsers: getUsers,
  saveUsers: saveUsers,
  findUserByEmail: findUserByEmail,
  findUserByUsername: findUserByUsername,
  generatePasswordHash: generatePasswordHash,
  checkPasswordHash: checkPasswordHash,
  getCompanies: getCompanies,
  saveCompanies: saveCompanies,
  getReviewLogs: getReviewLogs,
  saveReviewLogs: saveReviewLogs,
  getPayments: getPayments,
  savePayments: savePayments,
  getSupplierNames: getSupplierNames,
  getContractList: getContractList,
  PAYMENT_STAGES: PAYMENT_STAGES,
  matchCompany: matchCompany,
  recomputeAllDirections: recomputeAllDirections,
  paymentInfo: paymentInfo,
  genId: genId,
};
